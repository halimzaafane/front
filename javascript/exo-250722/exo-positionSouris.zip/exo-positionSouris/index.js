function mousemove(event) {
  console.log(
    "pageX: ",
    event.pageX,
    "pageY: ",
    event.pageY,
    "clientX: ",
    event.clientX,
    "clientY:",
    event.clientY
  );
}

window.addEventListener("mousemove", mousemove);
